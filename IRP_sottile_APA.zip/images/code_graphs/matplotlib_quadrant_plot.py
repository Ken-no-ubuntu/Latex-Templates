import matplotlib.pyplot as plt
import numpy as np

# Create figure and axis
fig, ax = plt.subplots(1, 1, figsize=(12, 10))

# Data points with their coordinates and labels
points = {
    "La voix des humbles": (0.8, 0.85),
    "La voix indigène": (0.4, 0.7),
    "La défense": (0.3, 0.5),
    "L'echo d'Alger": (-0.7, -0.3),
    "Alger": (-0.6, -0.4),
    "Le spectacle d'Afrique algéro-républicain": (0.1, -0.6),
    "L'echo d'Oran": (0.9, -0.85)
}

# Plot points with larger markers
for label, (x, y) in points.items():
    ax.scatter(x, y, s=200, color='red', alpha=0.7, zorder=3)
    
    # Add labels with larger font size
    if label == "Alger":
        # Special formatting for "Alger" - make it larger and different style
        ax.text(x, y-0.08, label, fontsize=18, fontweight='bold', 
                ha='center', va='top', color='red')
    else:
        ax.text(x, y+0.05, label, fontsize=14, ha='center', va='bottom', 
                color='red', fontweight='normal')

# Set axis limits
ax.set_xlim(-1, 1)
ax.set_ylim(-1, 1)

# Add grid lines at x=0 and y=0
ax.axhline(y=0, color='black', linestyle='-', linewidth=1)
ax.axvline(x=0, color='black', linestyle='-', linewidth=1)

# Remove top and right spines for cleaner look
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.spines['bottom'].set_position('zero')
ax.spines['left'].set_position('zero')

# Add axis labels with larger font - positioned outside the plot area
ax.set_xlabel('Left-Right Political Spectrum', fontsize=16, fontweight='bold')
ax.set_ylabel('Indigenous-Assimilationist Spectrum', fontsize=16, fontweight='bold', rotation=90)

# Move the axis labels to standard positions (outside the plot)
ax.xaxis.set_label_coords(0.5, -0.08)  # Center horizontally, below the plot
ax.yaxis.set_label_coords(-0.08, 0.5)  # Left of the plot, center vertically

# Set tick parameters for larger ticks
ax.tick_params(axis='both', which='major', labelsize=12)

# Add subtle grid
ax.grid(True, alpha=0.3, linestyle='--')

# Set title
ax.set_title('Political and Cultural Positioning of Algerian Publications', 
             fontsize=18, fontweight='bold', pad=20)

# Adjust layout to prevent label cutoff
plt.tight_layout()

# Show the plot
plt.show()

# Optional: Save the figure
plt.savefig(r"C:\Users\jyoji\Downloads\plot_alg.png", dpi=300, bbox_inches='tight')